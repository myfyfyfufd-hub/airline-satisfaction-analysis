/* ============================================================================
   AIRLINE PASSENGER SATISFACTION - CLEANING, VALIDATION AND ANALYSIS
   ============================================================================
   SQL dialect      : PostgreSQL 12+ (also runs on DuckDB; see portability notes)
   Source files     : train.csv (103,904 rows) and test.csv (25,976 rows)
                      Same 25 columns in both, no overlapping ids.
   Staging tables   : stg_train, stg_test   (you must load these, see section 2)
   Objects created  : stg_train, stg_test (tables); v_airline_raw, v_airline_clean,
                      v_dq_results (views). Nothing is dropped or deleted except
                      DROP VIEW IF EXISTS on the three views this script owns.
   All analysis queries in sections 3 and 7-10 are read-only SELECTs.

   Cleaning assumptions (identical to the Python script and the Excel workbook)
   1. train and test are stacked; a source column keeps the origin.
   2. The CSV column "Unnamed: 0" is a per-file row counter -> stored as row_index,
      not used in analysis.
   3. Service ratings use a 1-5 scale. A recorded 0 is treated as "not rated /
      not applicable" and converted to NULL (excluded from averages).
   4. arrival_delay_min is blank for 393 rows. It is left NULL (no imputation).
   5. Category labels are standardised ('disloyal Customer' -> 'Disloyal Customer',
      'Business travel' -> 'Business Travel', satisfaction labels capitalised).
   6. Delay outliers are FLAGGED using Q3 + 3 x IQR, never removed.
   7. satisfied_flag = 1 when satisfaction = 'Satisfied'.
   8. avg_service_rating = mean of the passenger's non-NULL ratings (14 services).

   Dialect-specific features: percentile_cont ... WITHIN GROUP, CORR(),
   CROSS JOIN LATERAL (VALUES ...), FILTER (WHERE ...), \copy (psql meta-command).
   ============================================================================ */


/* ============================================================================
   1. HEADER / ASSUMPTIONS  (see above)
   ============================================================================ */


/* ============================================================================
   2. STAGING TABLES  (raw layer - loaded exactly as in the CSV files)
   ============================================================================ */
CREATE TABLE IF NOT EXISTS stg_train (
    row_index                         INTEGER,   -- CSV column "Unnamed: 0"
    id                                BIGINT,
    gender                            TEXT,
    customer_type                     TEXT,
    age                               INTEGER,
    type_of_travel                    TEXT,
    travel_class                      TEXT,      -- CSV column "Class"
    flight_distance                   INTEGER,
    inflight_wifi_service             INTEGER,
    departure_arrival_time_convenient INTEGER,
    ease_of_online_booking            INTEGER,
    gate_location                     INTEGER,
    food_and_drink                    INTEGER,
    online_boarding                   INTEGER,
    seat_comfort                      INTEGER,
    inflight_entertainment            INTEGER,
    on_board_service                  INTEGER,
    leg_room_service                  INTEGER,
    baggage_handling                  INTEGER,
    checkin_service                   INTEGER,
    inflight_service                  INTEGER,
    cleanliness                       INTEGER,
    departure_delay_min               INTEGER,
    arrival_delay_min                 NUMERIC,   -- has blanks in the source
    satisfaction                      TEXT
);
CREATE TABLE IF NOT EXISTS stg_test (LIKE stg_train INCLUDING ALL);

/* Load the data (run in psql from the folder that holds the CSVs).
   Column order of the CSV matches the table, so no column list is needed.

   \copy stg_train FROM 'train.csv' WITH (FORMAT csv, HEADER true)
   \copy stg_test  FROM 'test.csv'  WITH (FORMAT csv, HEADER true)

   DuckDB equivalent:
   INSERT INTO stg_train SELECT * FROM read_csv('train.csv', header=true);
   INSERT INTO stg_test  SELECT * FROM read_csv('test.csv',  header=true);
*/

DROP VIEW IF EXISTS v_dq_results;
DROP VIEW IF EXISTS v_airline_clean;
DROP VIEW IF EXISTS v_airline_raw;

CREATE VIEW v_airline_raw AS
SELECT 'train' AS source, t.* FROM stg_train t
UNION ALL
SELECT 'test'  AS source, t.* FROM stg_test  t;


/* ============================================================================
   3. SCHEMA AND DATA PROFILING
   ============================================================================ */

-- 3.1 Row counts by source and overall satisfaction mix
SELECT source,
       COUNT(*)                                        AS rows_loaded,
       COUNT(DISTINCT id)                              AS distinct_ids,
       MIN(age) AS min_age, MAX(age) AS max_age,
       MIN(flight_distance) AS min_distance, MAX(flight_distance) AS max_distance,
       MAX(departure_delay_min) AS max_departure_delay,
       MAX(arrival_delay_min)   AS max_arrival_delay
FROM v_airline_raw
GROUP BY source
ORDER BY source;

-- 3.2 Distinct values of every categorical column (look for inconsistent labels)
SELECT 'gender' AS column_name, gender AS value, COUNT(*) AS n FROM v_airline_raw GROUP BY gender
UNION ALL SELECT 'customer_type',  customer_type,  COUNT(*) FROM v_airline_raw GROUP BY customer_type
UNION ALL SELECT 'type_of_travel', type_of_travel, COUNT(*) FROM v_airline_raw GROUP BY type_of_travel
UNION ALL SELECT 'travel_class',   travel_class,   COUNT(*) FROM v_airline_raw GROUP BY travel_class
UNION ALL SELECT 'satisfaction',   satisfaction,   COUNT(*) FROM v_airline_raw GROUP BY satisfaction
ORDER BY column_name, value;

-- 3.3 Distribution of each rating value 0-5 (a 0 is outside the 1-5 scale)
SELECT s.service, s.rating, COUNT(*) AS passengers
FROM v_airline_raw r
CROSS JOIN LATERAL (VALUES
    ('Inflight wifi service', r.inflight_wifi_service),
    ('Departure/Arrival time convenient', r.departure_arrival_time_convenient),
    ('Ease of Online booking', r.ease_of_online_booking),
    ('Gate location', r.gate_location),
    ('Food and drink', r.food_and_drink),
    ('Online boarding', r.online_boarding),
    ('Seat comfort', r.seat_comfort),
    ('Inflight entertainment', r.inflight_entertainment),
    ('On-board service', r.on_board_service),
    ('Leg room service', r.leg_room_service),
    ('Baggage handling', r.baggage_handling),
    ('Checkin service', r.checkin_service),
    ('Inflight service', r.inflight_service),
    ('Cleanliness', r.cleanliness)
) AS s(service, rating)
GROUP BY s.service, s.rating
ORDER BY s.service, s.rating;


/* ============================================================================
   4 + 5 + 6. CLEANING / NORMALISATION -> CLEAN ANALYTICAL VIEW
   Raw data stays untouched in stg_*; every transformation happens here.
   ============================================================================ */
CREATE VIEW v_airline_clean AS
WITH base AS (
    SELECT
        source,
        id,
        TRIM(gender) AS gender,
        CASE TRIM(customer_type)
             WHEN 'disloyal Customer' THEN 'Disloyal Customer'
             ELSE TRIM(customer_type) END                       AS customer_type,
        age,
        CASE TRIM(type_of_travel)
             WHEN 'Business travel' THEN 'Business Travel'
             ELSE TRIM(type_of_travel) END                      AS type_of_travel,
        TRIM(travel_class)                                      AS travel_class,
        flight_distance,
        -- 0 = not rated -> NULL
        NULLIF(inflight_wifi_service, 0)             AS inflight_wifi_service,
        NULLIF(departure_arrival_time_convenient, 0) AS departure_arrival_time_convenient,
        NULLIF(ease_of_online_booking, 0)            AS ease_of_online_booking,
        NULLIF(gate_location, 0)                     AS gate_location,
        NULLIF(food_and_drink, 0)                    AS food_and_drink,
        NULLIF(online_boarding, 0)                   AS online_boarding,
        NULLIF(seat_comfort, 0)                      AS seat_comfort,
        NULLIF(inflight_entertainment, 0)            AS inflight_entertainment,
        NULLIF(on_board_service, 0)                  AS on_board_service,
        NULLIF(leg_room_service, 0)                  AS leg_room_service,
        NULLIF(baggage_handling, 0)                  AS baggage_handling,
        NULLIF(checkin_service, 0)                   AS checkin_service,
        NULLIF(inflight_service, 0)                  AS inflight_service,
        NULLIF(cleanliness, 0)                       AS cleanliness,
        departure_delay_min,
        arrival_delay_min,                           -- NULL kept, not imputed
        CASE TRIM(satisfaction)
             WHEN 'satisfied'               THEN 'Satisfied'
             WHEN 'neutral or dissatisfied' THEN 'Neutral or Dissatisfied'
             ELSE TRIM(satisfaction) END             AS satisfaction
    FROM v_airline_raw
),
thresholds AS (   -- Q3 + 3 x IQR outlier limits (same rule as the Python script)
    SELECT
        percentile_cont(0.75) WITHIN GROUP (ORDER BY departure_delay_min)
          + 3 * (percentile_cont(0.75) WITHIN GROUP (ORDER BY departure_delay_min)
               - percentile_cont(0.25) WITHIN GROUP (ORDER BY departure_delay_min)) AS dep_limit,
        percentile_cont(0.75) WITHIN GROUP (ORDER BY arrival_delay_min)
          + 3 * (percentile_cont(0.75) WITHIN GROUP (ORDER BY arrival_delay_min)
               - percentile_cont(0.25) WITHIN GROUP (ORDER BY arrival_delay_min)) AS arr_limit
    FROM base
)
SELECT
    b.*,
    CASE WHEN b.age < 18 THEN 'Under 18'
         WHEN b.age <= 24 THEN '18 to 24'
         WHEN b.age <= 34 THEN '25 to 34'
         WHEN b.age <= 44 THEN '35 to 44'
         WHEN b.age <= 54 THEN '45 to 54'
         WHEN b.age <= 64 THEN '55 to 64'
         ELSE '65 and over' END                                  AS age_group,
    CASE WHEN b.flight_distance <= 500  THEN 'Under 500'
         WHEN b.flight_distance <= 1000 THEN '500 to 999'
         WHEN b.flight_distance <= 2000 THEN '1000 to 1999'
         WHEN b.flight_distance <= 3000 THEN '2000 to 2999'
         ELSE '3000 or more' END                                 AS distance_band,
    CASE WHEN b.arrival_delay_min IS NULL THEN NULL
         WHEN b.arrival_delay_min <= 0   THEN 'On time (0 min)'
         WHEN b.arrival_delay_min <= 14  THEN '1 to 14 min'
         WHEN b.arrival_delay_min <= 59  THEN '15 to 59 min'
         WHEN b.arrival_delay_min <= 179 THEN '60 to 179 min'
         ELSE '180+ min' END                                     AS arrival_delay_band,
    CASE WHEN b.arrival_delay_min IS NULL THEN NULL
         WHEN b.arrival_delay_min >= 15 THEN 1 ELSE 0 END        AS delayed_15_plus,
    CASE WHEN b.satisfaction = 'Satisfied' THEN 1 ELSE 0 END     AS satisfied_flag,
    -- mean of the non-NULL ratings of this passenger
    ( COALESCE(b.inflight_wifi_service,0) + COALESCE(b.departure_arrival_time_convenient,0)
    + COALESCE(b.ease_of_online_booking,0) + COALESCE(b.gate_location,0)
    + COALESCE(b.food_and_drink,0) + COALESCE(b.online_boarding,0)
    + COALESCE(b.seat_comfort,0) + COALESCE(b.inflight_entertainment,0)
    + COALESCE(b.on_board_service,0) + COALESCE(b.leg_room_service,0)
    + COALESCE(b.baggage_handling,0) + COALESCE(b.checkin_service,0)
    + COALESCE(b.inflight_service,0) + COALESCE(b.cleanliness,0) ) * 1.0
    / NULLIF(
      (CASE WHEN b.inflight_wifi_service IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.departure_arrival_time_convenient IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.ease_of_online_booking IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.gate_location IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.food_and_drink IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.online_boarding IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.seat_comfort IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.inflight_entertainment IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.on_board_service IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.leg_room_service IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.baggage_handling IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.checkin_service IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.inflight_service IS NOT NULL THEN 1 ELSE 0 END
     + CASE WHEN b.cleanliness IS NOT NULL THEN 1 ELSE 0 END), 0) AS avg_service_rating,
    CASE WHEN b.arrival_delay_min IS NULL THEN 1 ELSE 0 END      AS arrival_delay_missing,
    CASE WHEN b.departure_delay_min > t.dep_limit THEN 1 ELSE 0 END AS departure_delay_outlier,
    CASE WHEN b.arrival_delay_min  > t.arr_limit THEN 1 ELSE 0 END  AS arrival_delay_outlier
FROM base b
CROSS JOIN thresholds t;


/* ============================================================================
   DATA-QUALITY VALIDATION ENGINE
   Standard result columns: check_name, check_type, actual_value,
   expected_condition, status (PASS / WARN / FAIL), severity.
   A non-zero count is only FAIL where the data rules prove zero is required.
   ============================================================================ */
CREATE VIEW v_dq_results AS
WITH
raw_counts AS (
    SELECT COUNT(*) AS n_raw,
           COUNT(DISTINCT id) AS n_ids,
           COUNT(*) FILTER (WHERE source = 'train') AS n_train,
           COUNT(*) FILTER (WHERE source = 'test')  AS n_test
    FROM v_airline_raw
),
dup_rows AS (
    SELECT COALESCE(SUM(c - 1), 0) AS n
    FROM (SELECT COUNT(*) AS c
          FROM v_airline_raw
          GROUP BY id, gender, customer_type, age, type_of_travel, travel_class, flight_distance,
                   inflight_wifi_service, departure_arrival_time_convenient, ease_of_online_booking,
                   gate_location, food_and_drink, online_boarding, seat_comfort, inflight_entertainment,
                   on_board_service, leg_room_service, baggage_handling, checkin_service, inflight_service,
                   cleanliness, departure_delay_min, arrival_delay_min, satisfaction
          HAVING COUNT(*) > 1) d
),
shared_ids AS (
    SELECT COUNT(*) AS n
    FROM stg_train a JOIN stg_test b ON a.id = b.id
),
zero_ratings AS (
    SELECT COUNT(*) AS n
    FROM v_airline_raw r
    CROSS JOIN LATERAL (VALUES
        (r.inflight_wifi_service), (r.departure_arrival_time_convenient), (r.ease_of_online_booking),
        (r.gate_location), (r.food_and_drink), (r.online_boarding), (r.seat_comfort),
        (r.inflight_entertainment), (r.on_board_service), (r.leg_room_service), (r.baggage_handling),
        (r.checkin_service), (r.inflight_service), (r.cleanliness)) AS s(rating)
    WHERE s.rating = 0
),
bad_ratings AS (
    SELECT COUNT(*) AS n
    FROM v_airline_raw r
    CROSS JOIN LATERAL (VALUES
        (r.inflight_wifi_service), (r.departure_arrival_time_convenient), (r.ease_of_online_booking),
        (r.gate_location), (r.food_and_drink), (r.online_boarding), (r.seat_comfort),
        (r.inflight_entertainment), (r.on_board_service), (r.leg_room_service), (r.baggage_handling),
        (r.checkin_service), (r.inflight_service), (r.cleanliness)) AS s(rating)
    WHERE s.rating < 0 OR s.rating > 5
),
checks AS (
    SELECT 'Rows loaded (train + test)' AS check_name, 'completeness' AS check_type,
           n_raw AS actual_value, '> 0' AS expected_condition,
           CASE WHEN n_raw > 0 THEN 'PASS' ELSE 'FAIL' END AS status, 'HIGH' AS severity
    FROM raw_counts
    UNION ALL SELECT 'Duplicate passenger ids', 'uniqueness', n_raw - n_ids, '= 0',
           CASE WHEN n_raw - n_ids = 0 THEN 'PASS' ELSE 'WARN' END, 'MEDIUM' FROM raw_counts
    UNION ALL SELECT 'Fully duplicated rows', 'uniqueness', n, '= 0',
           CASE WHEN n = 0 THEN 'PASS' ELSE 'WARN' END, 'MEDIUM' FROM dup_rows
    UNION ALL SELECT 'Ids present in both train and test', 'uniqueness', n, '= 0',
           CASE WHEN n = 0 THEN 'PASS' ELSE 'WARN' END, 'MEDIUM' FROM shared_ids
    UNION ALL SELECT 'NULLs in key categorical columns', 'completeness',
           COUNT(*) FILTER (WHERE gender IS NULL OR customer_type IS NULL OR type_of_travel IS NULL
                              OR travel_class IS NULL OR satisfaction IS NULL OR age IS NULL
                              OR flight_distance IS NULL), '= 0',
           CASE WHEN COUNT(*) FILTER (WHERE gender IS NULL OR customer_type IS NULL OR type_of_travel IS NULL
                              OR travel_class IS NULL OR satisfaction IS NULL OR age IS NULL
                              OR flight_distance IS NULL) = 0 THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
    FROM v_airline_raw
    UNION ALL SELECT 'Blank arrival_delay_min', 'completeness',
           COUNT(*) FILTER (WHERE arrival_delay_min IS NULL), '= 0 (kept NULL, not imputed)',
           CASE WHEN COUNT(*) FILTER (WHERE arrival_delay_min IS NULL) = 0 THEN 'PASS' ELSE 'WARN' END, 'LOW'
    FROM v_airline_raw
    UNION ALL SELECT 'Ratings equal to 0 (treated as not rated)', 'validity', n,
           '= 0 (0 is outside the 1-5 scale)',
           CASE WHEN n = 0 THEN 'PASS' ELSE 'WARN' END, 'MEDIUM' FROM zero_ratings
    UNION ALL SELECT 'Ratings outside 0-5', 'validity', n, '= 0',
           CASE WHEN n = 0 THEN 'PASS' ELSE 'FAIL' END, 'HIGH' FROM bad_ratings
    UNION ALL SELECT 'Age outside 0-110', 'validity',
           COUNT(*) FILTER (WHERE age < 0 OR age > 110), '= 0',
           CASE WHEN COUNT(*) FILTER (WHERE age < 0 OR age > 110) = 0 THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
    FROM v_airline_raw
    UNION ALL SELECT 'Flight distance <= 0', 'validity',
           COUNT(*) FILTER (WHERE flight_distance <= 0), '= 0',
           CASE WHEN COUNT(*) FILTER (WHERE flight_distance <= 0) = 0 THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
    FROM v_airline_raw
    UNION ALL SELECT 'Negative delays', 'validity',
           COUNT(*) FILTER (WHERE departure_delay_min < 0 OR arrival_delay_min < 0), '= 0',
           CASE WHEN COUNT(*) FILTER (WHERE departure_delay_min < 0 OR arrival_delay_min < 0) = 0
                THEN 'PASS' ELSE 'FAIL' END, 'MEDIUM'
    FROM v_airline_raw
    UNION ALL SELECT 'Unexpected category values', 'consistency',
           COUNT(*) FILTER (WHERE gender NOT IN ('Female','Male')
              OR customer_type NOT IN ('Loyal Customer','disloyal Customer')
              OR type_of_travel NOT IN ('Business travel','Personal Travel')
              OR travel_class NOT IN ('Business','Eco','Eco Plus')
              OR satisfaction NOT IN ('satisfied','neutral or dissatisfied')), '= 0',
           CASE WHEN COUNT(*) FILTER (WHERE gender NOT IN ('Female','Male')
              OR customer_type NOT IN ('Loyal Customer','disloyal Customer')
              OR type_of_travel NOT IN ('Business travel','Personal Travel')
              OR travel_class NOT IN ('Business','Eco','Eco Plus')
              OR satisfaction NOT IN ('satisfied','neutral or dissatisfied')) = 0
                THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
    FROM v_airline_raw
    UNION ALL SELECT 'Arrival delay smaller than departure delay', 'plausibility',
           COUNT(*) FILTER (WHERE arrival_delay_min < departure_delay_min),
           'informational: time can be made up in flight', 'PASS', 'INFO'
    FROM v_airline_raw
    UNION ALL SELECT 'Row count after cleaning equals raw row count', 'reconciliation',
           (SELECT COUNT(*) FROM v_airline_clean), '= raw row count',
           CASE WHEN (SELECT COUNT(*) FROM v_airline_clean) = (SELECT COUNT(*) FROM v_airline_raw)
                THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
    UNION ALL SELECT 'Duplicate ids after cleaning', 'uniqueness',
           (SELECT COUNT(*) - COUNT(DISTINCT id) FROM v_airline_clean), '= 0',
           CASE WHEN (SELECT COUNT(*) - COUNT(DISTINCT id) FROM v_airline_clean) = 0
                THEN 'PASS' ELSE 'FAIL' END, 'HIGH'
)
SELECT * FROM checks;

-- Run the validation engine
SELECT * FROM v_dq_results ORDER BY CASE status WHEN 'FAIL' THEN 1 WHEN 'WARN' THEN 2 ELSE 3 END, check_name;

-- Zero-rating and blank counts per service (detail behind the WARN above)
SELECT s.service,
       COUNT(*) FILTER (WHERE s.rating = 0)               AS zero_ratings,
       ROUND(1.0 * COUNT(*) FILTER (WHERE s.rating = 0) / COUNT(*), 4) AS share_zero
FROM v_airline_raw r
CROSS JOIN LATERAL (VALUES
    ('Inflight wifi service', r.inflight_wifi_service),
    ('Departure/Arrival time convenient', r.departure_arrival_time_convenient),
    ('Ease of Online booking', r.ease_of_online_booking),
    ('Gate location', r.gate_location),
    ('Food and drink', r.food_and_drink),
    ('Online boarding', r.online_boarding),
    ('Seat comfort', r.seat_comfort),
    ('Inflight entertainment', r.inflight_entertainment),
    ('On-board service', r.on_board_service),
    ('Leg room service', r.leg_room_service),
    ('Baggage handling', r.baggage_handling),
    ('Checkin service', r.checkin_service),
    ('Inflight service', r.inflight_service),
    ('Cleanliness', r.cleanliness)
) AS s(service, rating)
GROUP BY s.service
ORDER BY zero_ratings DESC;


/* ============================================================================
   7. KPI AND BUSINESS ANALYSIS
   ============================================================================ */

-- 7.1 Headline KPIs (same definitions as the Excel Dashboard)
SELECT COUNT(*)                                             AS passengers,
       SUM(satisfied_flag)                                  AS satisfied_passengers,
       AVG(satisfied_flag * 1.0)                            AS satisfaction_rate,
       AVG(age * 1.0)                                       AS avg_age,
       AVG(flight_distance * 1.0)                           AS avg_flight_distance_miles,
       AVG(departure_delay_min * 1.0)                       AS avg_departure_delay_min,
       AVG(arrival_delay_min)                               AS avg_arrival_delay_min,
       AVG(delayed_15_plus * 1.0)                           AS share_delayed_15_plus,
       AVG(avg_service_rating)                              AS avg_service_rating
FROM v_airline_clean;

-- 7.2 Satisfaction by every segment dimension, with share of passengers
WITH seg AS (
    SELECT 'Class' AS dimension, travel_class AS segment, satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Type of Travel', type_of_travel, satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Customer Type',  customer_type,  satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Gender',         gender,         satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Age Group',      age_group,      satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Distance Band',  distance_band,  satisfied_flag, avg_service_rating FROM v_airline_clean
    UNION ALL SELECT 'Source file',    source,         satisfied_flag, avg_service_rating FROM v_airline_clean
)
SELECT dimension, segment,
       COUNT(*)                                                   AS passengers,
       AVG(satisfied_flag * 1.0)                                  AS satisfaction_rate,
       AVG(avg_service_rating)                                    AS avg_service_rating,
       COUNT(*) * 1.0 / SUM(COUNT(*)) OVER (PARTITION BY dimension) AS share_of_passengers,
       RANK() OVER (PARTITION BY dimension ORDER BY AVG(satisfied_flag * 1.0) DESC) AS rank_in_dimension
FROM seg
GROUP BY dimension, segment
ORDER BY dimension, rank_in_dimension;

-- 7.3 Class x type of travel
SELECT travel_class, type_of_travel,
       COUNT(*)                          AS passengers,
       AVG(satisfied_flag * 1.0)         AS satisfaction_rate
FROM v_airline_clean
GROUP BY travel_class, type_of_travel
ORDER BY travel_class, type_of_travel;

-- 7.4 Arrival delay vs satisfaction (rows with a known arrival delay only)
SELECT arrival_delay_band,
       COUNT(*)                         AS passengers,
       AVG(satisfied_flag * 1.0)        AS satisfaction_rate,
       COUNT(*) * 1.0 / SUM(COUNT(*)) OVER () AS share_of_known_delays
FROM v_airline_clean
WHERE arrival_delay_band IS NOT NULL
GROUP BY arrival_delay_band
ORDER BY MIN(arrival_delay_min);

-- 7.5 Service ratings: average, satisfaction when rated high vs low, correlation
WITH long_ratings AS (
    SELECT s.service, s.rating, c.satisfied_flag
    FROM v_airline_clean c
    CROSS JOIN LATERAL (VALUES
        ('Inflight wifi service', c.inflight_wifi_service),
        ('Departure/Arrival time convenient', c.departure_arrival_time_convenient),
        ('Ease of Online booking', c.ease_of_online_booking),
        ('Gate location', c.gate_location),
        ('Food and drink', c.food_and_drink),
        ('Online boarding', c.online_boarding),
        ('Seat comfort', c.seat_comfort),
        ('Inflight entertainment', c.inflight_entertainment),
        ('On-board service', c.on_board_service),
        ('Leg room service', c.leg_room_service),
        ('Baggage handling', c.baggage_handling),
        ('Checkin service', c.checkin_service),
        ('Inflight service', c.inflight_service),
        ('Cleanliness', c.cleanliness)
    ) AS s(service, rating)
)
SELECT service,
       AVG(rating * 1.0)                                                         AS avg_rating,
       COUNT(rating)                                                             AS rated_passengers,
       COUNT(*) - COUNT(rating)                                                  AS not_rated,
       AVG(satisfied_flag * 1.0) FILTER (WHERE rating >= 4)                      AS satisfied_rate_if_rated_4_5,
       AVG(satisfied_flag * 1.0) FILTER (WHERE rating <= 2)                      AS satisfied_rate_if_rated_1_2,
       AVG(satisfied_flag * 1.0) FILTER (WHERE rating >= 4)
         - AVG(satisfied_flag * 1.0) FILTER (WHERE rating <= 2)                  AS satisfaction_gap,
       CORR(rating * 1.0, satisfied_flag * 1.0)                                  AS correlation_with_satisfied,
       RANK() OVER (ORDER BY CORR(rating * 1.0, satisfied_flag * 1.0) DESC)      AS correlation_rank
FROM long_ratings
GROUP BY service
ORDER BY correlation_with_satisfied DESC;


/* ============================================================================
   8. ADVANCED ANALYSIS
   ============================================================================ */

-- 8.1 Cumulative contribution of passengers by age group (youngest to oldest)
WITH g AS (
    SELECT age_group, MIN(age) AS youngest_age, COUNT(*) AS passengers, SUM(satisfied_flag) AS satisfied
    FROM v_airline_clean GROUP BY age_group
)
SELECT age_group, passengers, satisfied,
       SUM(passengers) OVER (ORDER BY youngest_age) * 1.0 / SUM(passengers) OVER () AS cumulative_passenger_share
FROM g
ORDER BY youngest_age;

-- 8.2 Business vs Eco average rating per service and the gap (where Eco trails most)
WITH long_ratings AS (
    SELECT c.travel_class, s.service, s.rating
    FROM v_airline_clean c
    CROSS JOIN LATERAL (VALUES
        ('Inflight wifi service', c.inflight_wifi_service),
        ('Departure/Arrival time convenient', c.departure_arrival_time_convenient),
        ('Ease of Online booking', c.ease_of_online_booking),
        ('Gate location', c.gate_location),
        ('Food and drink', c.food_and_drink),
        ('Online boarding', c.online_boarding),
        ('Seat comfort', c.seat_comfort),
        ('Inflight entertainment', c.inflight_entertainment),
        ('On-board service', c.on_board_service),
        ('Leg room service', c.leg_room_service),
        ('Baggage handling', c.baggage_handling),
        ('Checkin service', c.checkin_service),
        ('Inflight service', c.inflight_service),
        ('Cleanliness', c.cleanliness)
    ) AS s(service, rating)
)
SELECT service,
       AVG(rating * 1.0) FILTER (WHERE travel_class = 'Business') AS business_avg,
       AVG(rating * 1.0) FILTER (WHERE travel_class = 'Eco Plus') AS eco_plus_avg,
       AVG(rating * 1.0) FILTER (WHERE travel_class = 'Eco')      AS eco_avg,
       AVG(rating * 1.0) FILTER (WHERE travel_class = 'Business')
         - AVG(rating * 1.0) FILTER (WHERE travel_class = 'Eco')  AS business_minus_eco
FROM long_ratings
GROUP BY service
ORDER BY business_minus_eco DESC;

-- 8.3 Delay outliers flagged (kept in the data)
SELECT SUM(departure_delay_outlier) AS departure_delay_outliers,
       SUM(arrival_delay_outlier)   AS arrival_delay_outliers,
       MAX(departure_delay_min)     AS max_departure_delay,
       MAX(arrival_delay_min)       AS max_arrival_delay,
       AVG(satisfied_flag * 1.0) FILTER (WHERE arrival_delay_outlier = 1) AS satisfaction_rate_of_arrival_outliers
FROM v_airline_clean;

-- 8.4 Train vs test sanity check (similar populations => safe to combine)
SELECT source, COUNT(*) AS passengers, AVG(satisfied_flag * 1.0) AS satisfaction_rate,
       AVG(age * 1.0) AS avg_age, AVG(flight_distance * 1.0) AS avg_distance
FROM v_airline_clean
GROUP BY source;


/* ============================================================================
   9. FINAL QC / RECONCILIATION  (raw layer vs clean layer)
   Any FAIL means a cleaning step changed a business total unintentionally.
   ============================================================================ */
WITH r AS (
    SELECT COUNT(*) AS n, COUNT(DISTINCT id) AS ids,
           COUNT(*) FILTER (WHERE satisfaction = 'satisfied') AS satisfied,
           COUNT(*) FILTER (WHERE travel_class = 'Business')  AS business,
           COUNT(*) FILTER (WHERE arrival_delay_min IS NULL)  AS null_arrival,
           MIN(age) AS min_age, MAX(age) AS max_age,
           SUM(flight_distance) AS total_distance
    FROM v_airline_raw
),
c AS (
    SELECT COUNT(*) AS n, COUNT(DISTINCT id) AS ids,
           COUNT(*) FILTER (WHERE satisfaction = 'Satisfied') AS satisfied,
           COUNT(*) FILTER (WHERE travel_class = 'Business')  AS business,
           COUNT(*) FILTER (WHERE arrival_delay_min IS NULL)  AS null_arrival,
           MIN(age) AS min_age, MAX(age) AS max_age,
           SUM(flight_distance) AS total_distance
    FROM v_airline_clean
)
SELECT 'row count' AS metric, r.n AS raw_value, c.n AS clean_value,
       CASE WHEN r.n = c.n THEN 'PASS' ELSE 'FAIL' END AS status FROM r, c
UNION ALL SELECT 'distinct ids', r.ids, c.ids, CASE WHEN r.ids = c.ids THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'satisfied passengers', r.satisfied, c.satisfied, CASE WHEN r.satisfied = c.satisfied THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'Business class passengers', r.business, c.business, CASE WHEN r.business = c.business THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'NULL arrival delays', r.null_arrival, c.null_arrival, CASE WHEN r.null_arrival = c.null_arrival THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'minimum age', r.min_age, c.min_age, CASE WHEN r.min_age = c.min_age THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'maximum age', r.max_age, c.max_age, CASE WHEN r.max_age = c.max_age THEN 'PASS' ELSE 'FAIL' END FROM r, c
UNION ALL SELECT 'total flight distance', r.total_distance, c.total_distance, CASE WHEN r.total_distance = c.total_distance THEN 'PASS' ELSE 'FAIL' END FROM r, c;

-- Segment totals must add back to the passenger total (guards against join/band gaps)
SELECT 'age_group'     AS dimension, SUM(n) AS summed, (SELECT COUNT(*) FROM v_airline_clean) AS expected,
       CASE WHEN SUM(n) = (SELECT COUNT(*) FROM v_airline_clean) THEN 'PASS' ELSE 'FAIL' END AS status
FROM (SELECT COUNT(*) AS n FROM v_airline_clean GROUP BY age_group) a
UNION ALL
SELECT 'distance_band', SUM(n), (SELECT COUNT(*) FROM v_airline_clean),
       CASE WHEN SUM(n) = (SELECT COUNT(*) FROM v_airline_clean) THEN 'PASS' ELSE 'FAIL' END
FROM (SELECT COUNT(*) AS n FROM v_airline_clean GROUP BY distance_band) d
UNION ALL
SELECT 'arrival_delay_band (+ NULL)', SUM(n), (SELECT COUNT(*) FROM v_airline_clean),
       CASE WHEN SUM(n) = (SELECT COUNT(*) FROM v_airline_clean) THEN 'PASS' ELSE 'FAIL' END
FROM (SELECT COUNT(*) AS n FROM v_airline_clean GROUP BY arrival_delay_band) b;


/* ============================================================================
   10. REUSABLE OUTPUT VIEW  (one row per passenger, ready for BI tools)
   ============================================================================ */
-- v_airline_clean (created in section 4-6) is the analytical dataset:
--   SELECT * FROM v_airline_clean;
-- v_dq_results is the validation report:
--   SELECT * FROM v_dq_results WHERE status <> 'PASS';
