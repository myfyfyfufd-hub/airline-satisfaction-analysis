#!/usr/bin/env python3
"""
Airline Passenger Satisfaction - cleaning, EDA and KPI script
=============================================================
Input : train.csv and test.csv (same 25-column schema, no overlapping ids)
Output: ./analysis_output/*.csv  (cleaned data, quality log, KPI and EDA tables)

Usage : python airline_satisfaction_analysis.py [folder_with_csvs]

Key cleaning decisions (documented so the SQL and Excel outputs match):
  1. train and test are stacked into one table; a 'Source' column keeps the origin.
  2. 'Unnamed: 0' is only the per-file row index, so it is dropped from the clean data.
  3. Service ratings use a 1-5 scale. A value of 0 is treated as "not rated / not
     applicable" and set to NaN. It is NOT averaged as a score of zero.
  4. 'Arrival Delay in Minutes' has blanks. They are left blank (no imputation),
     because the true value cannot be reliably derived from departure delay.
  5. Outliers (very long delays) are flagged, never removed.
"""
import os
import sys

import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------
# 1. LOAD
# ----------------------------------------------------------------------------
folder = sys.argv[1] if len(sys.argv) > 1 else "."
out_dir = os.path.join(folder, "analysis_output")
os.makedirs(out_dir, exist_ok=True)

train = pd.read_csv(os.path.join(folder, "train.csv"))
test = pd.read_csv(os.path.join(folder, "test.csv"))
train["Source"] = "train"
test["Source"] = "test"
raw = pd.concat([train, test], ignore_index=True)

# ----------------------------------------------------------------------------
# 2. INSPECT
# ----------------------------------------------------------------------------
RATING_COLS = [
    "Inflight wifi service", "Departure/Arrival time convenient",
    "Ease of Online booking", "Gate location", "Food and drink",
    "Online boarding", "Seat comfort", "Inflight entertainment",
    "On-board service", "Leg room service", "Baggage handling",
    "Checkin service", "Inflight service", "Cleanliness",
]
CAT_COLS = ["Gender", "Customer Type", "Type of Travel", "Class", "satisfaction"]

quality = []  # (check, actual_value, status, note)


def log(check, value, status, note=""):
    quality.append({"check": check, "actual_value": value, "status": status, "note": note})


log("Rows in train.csv", len(train), "INFO")
log("Rows in test.csv", len(test), "INFO")
log("Rows combined (raw)", len(raw), "INFO")
log("Fully duplicated rows (excluding Source / row index)",
    int(raw.drop(columns=["Unnamed: 0", "Source"]).duplicated().sum()),
    "PASS" if raw.drop(columns=["Unnamed: 0", "Source"]).duplicated().sum() == 0 else "WARN")
log("Duplicate passenger ids", int(raw["id"].duplicated().sum()),
    "PASS" if raw["id"].duplicated().sum() == 0 else "WARN")
log("Ids shared between train and test",
    len(set(train["id"]) & set(test["id"])),
    "PASS" if len(set(train["id"]) & set(test["id"])) == 0 else "WARN")

# ----------------------------------------------------------------------------
# 3. CLEAN
# ----------------------------------------------------------------------------
df = raw.drop(columns=["Unnamed: 0"]).copy()

# 3a. whitespace / label standardisation (categories are already consistent,
#     but trimming keeps the script safe if the data is refreshed)
for c in CAT_COLS:
    df[c] = df[c].astype(str).str.strip()
df["Customer Type"] = df["Customer Type"].replace({"disloyal Customer": "Disloyal Customer"})
df["Type of Travel"] = df["Type of Travel"].replace({"Business travel": "Business Travel"})
df["satisfaction"] = df["satisfaction"].replace({"neutral or dissatisfied": "Neutral or Dissatisfied",
                                                  "satisfied": "Satisfied"})

# 3b. 0 rating = not rated -> NaN
zero_counts = {c: int((df[c] == 0).sum()) for c in RATING_COLS}
for c in RATING_COLS:
    df[c] = df[c].replace(0, np.nan)
for c, n in zero_counts.items():
    if n:
        log(f"Zero ratings set to blank: {c}", n, "WARN",
            "0 treated as not rated; excluded from averages")

# 3c. missing arrival delay: keep blank, flag
missing_arr = int(df["Arrival Delay in Minutes"].isna().sum())
log("Blank Arrival Delay in Minutes", missing_arr, "WARN", "Left blank, not imputed")
df["Arrival Delay Missing"] = df["Arrival Delay in Minutes"].isna()

# 3d. outlier flag (delays beyond Q3 + 3*IQR)
for col, flag in [("Departure Delay in Minutes", "Departure Delay Outlier"),
                  ("Arrival Delay in Minutes", "Arrival Delay Outlier")]:
    q1, q3 = df[col].quantile([0.25, 0.75])
    upper = q3 + 3 * (q3 - q1)
    df[flag] = df[col] > upper
    log(f"Outliers flagged: {col} > {upper:.0f} min", int(df[flag].sum()), "INFO", "Flagged, kept in data")

# 3e. range checks
log("Age outside 0-110", int(((df["Age"] < 0) | (df["Age"] > 110)).sum()), "PASS")
log("Flight Distance <= 0", int((df["Flight Distance"] <= 0).sum()), "PASS")
log("Negative delays", int(((df["Departure Delay in Minutes"] < 0) |
                            (df["Arrival Delay in Minutes"] < 0)).sum()), "PASS")
arr_lt_dep = int((df["Arrival Delay in Minutes"] < df["Departure Delay in Minutes"]).sum())
log("Arrival delay smaller than departure delay", arr_lt_dep, "INFO",
    "Plausible: aircraft can make up time in the air")

# 3f. derived fields used by the dashboard
df["Age Group"] = pd.cut(df["Age"], bins=[0, 17, 24, 34, 44, 54, 64, 120],
                         labels=["Under 18", "18 to 24", "25 to 34", "35 to 44", "45 to 54", "55 to 64", "65 and over"])
df["Distance Band"] = pd.cut(df["Flight Distance"], bins=[0, 500, 1000, 2000, 3000, 10000],
                             labels=["Under 500", "500 to 999", "1000 to 1999", "2000 to 2999", "3000 or more"])
df["Delayed 15+ Min (Arrival)"] = np.where(df["Arrival Delay in Minutes"].isna(), np.nan,
                                           (df["Arrival Delay in Minutes"] >= 15).astype(float))
df["Satisfied Flag"] = (df["satisfaction"] == "Satisfied").astype(int)
df["Avg Service Rating"] = df[RATING_COLS].mean(axis=1)

log("Rows after cleaning", len(df), "PASS" if len(df) == len(raw) else "FAIL",
    "No rows removed; reconciles to raw")

# ----------------------------------------------------------------------------
# 4. EDA / KPIs
# ----------------------------------------------------------------------------
kpis = pd.DataFrame({
    "KPI": ["Passengers", "Satisfaction rate", "Average age", "Average flight distance (miles)",
            "Average departure delay (min)", "Average arrival delay (min)",
            "Share delayed 15+ min on arrival", "Average service rating (1-5)"],
    "Value": [len(df), df["Satisfied Flag"].mean(), df["Age"].mean(), df["Flight Distance"].mean(),
              df["Departure Delay in Minutes"].mean(), df["Arrival Delay in Minutes"].mean(),
              df["Delayed 15+ Min (Arrival)"].mean(), df["Avg Service Rating"].mean()],
})


def seg(col):
    g = df.groupby(col, observed=True).agg(Passengers=("id", "count"),
                                            Satisfaction_Rate=("Satisfied Flag", "mean"),
                                            Avg_Service_Rating=("Avg Service Rating", "mean")).reset_index()
    g["Share_of_Passengers"] = g["Passengers"] / g["Passengers"].sum()
    return g


segments = {c: seg(c) for c in ["Class", "Type of Travel", "Customer Type", "Gender", "Age Group",
                                "Distance Band", "Source"]}

# service ratings: mean, and satisfaction gap between those rating 4-5 vs 1-2
svc = []
for c in RATING_COLS:
    s = df[[c, "Satisfied Flag"]].dropna()
    svc.append({
        "Service": c,
        "Avg Rating": s[c].mean(),
        "Rated Passengers": len(s),
        "Not Rated": int(df[c].isna().sum()),
        "Satisfaction Rate if Rated 4-5": s.loc[s[c] >= 4, "Satisfied Flag"].mean(),
        "Satisfaction Rate if Rated 1-2": s.loc[s[c] <= 2, "Satisfied Flag"].mean(),
        "Correlation with Satisfied": s[c].corr(s["Satisfied Flag"]),
    })
svc = pd.DataFrame(svc)
svc["Satisfaction Gap (4-5 vs 1-2)"] = (svc["Satisfaction Rate if Rated 4-5"]
                                         - svc["Satisfaction Rate if Rated 1-2"])
svc = svc.sort_values("Correlation with Satisfied", ascending=False)

# delay effect
df["Arrival Delay Band"] = pd.cut(df["Arrival Delay in Minutes"], bins=[-1, 0, 14, 59, 179, 5000],
                                  labels=["On time (0 min)", "1 to 14 min", "15 to 59 min", "60 to 179 min", "180+ min"])
delay = (df.dropna(subset=["Arrival Delay Band"])
           .groupby("Arrival Delay Band", observed=True)
           .agg(Passengers=("id", "count"), Satisfaction_Rate=("Satisfied Flag", "mean")).reset_index())

# class x travel type cross-tab
cross = (df.groupby(["Class", "Type of Travel"], observed=True)
           .agg(Passengers=("id", "count"), Satisfaction_Rate=("Satisfied Flag", "mean")).reset_index())

# ----------------------------------------------------------------------------
# 5. EXPORT
# ----------------------------------------------------------------------------
df.to_csv(os.path.join(out_dir, "clean_data.csv"), index=False)
pd.DataFrame(quality).to_csv(os.path.join(out_dir, "data_quality_log.csv"), index=False)
kpis.to_csv(os.path.join(out_dir, "kpis.csv"), index=False)
svc.to_csv(os.path.join(out_dir, "service_ratings.csv"), index=False)
delay.to_csv(os.path.join(out_dir, "delay_vs_satisfaction.csv"), index=False)
cross.to_csv(os.path.join(out_dir, "class_by_travel.csv"), index=False)
for name, t in segments.items():
    t.to_csv(os.path.join(out_dir, f"segment_{name.replace(' ', '_').lower()}.csv"), index=False)

print(kpis.to_string(index=False))
print("\nOutputs written to", out_dir)
